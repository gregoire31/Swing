import javax.swing.*;
import java.awt.Color;
import java.awt.GridLayout;

class Salaires {


    public static void main(String[] args) {

        FenetreSaisie fens = new FenetreSaisie();

    }
}
