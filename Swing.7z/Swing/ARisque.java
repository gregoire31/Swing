interface ARisque {
    int PRIME = 200;
}
